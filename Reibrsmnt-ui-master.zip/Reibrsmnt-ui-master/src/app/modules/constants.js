// constants.js

(function() {
    'use strict';

    angular
        .module('Reibrsmnt')
        .constant('approve_type', {
            approve: 3,
            review:4,
            forward: 5,
            hold: 6,
            cleared: 7,
            reject: 8
        })
})();