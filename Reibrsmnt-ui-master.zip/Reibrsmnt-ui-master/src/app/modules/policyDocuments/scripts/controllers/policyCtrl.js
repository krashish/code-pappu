(function(){
  'use strict';
  angular.module('policy')
         .controller('policyCtrl', policyCtrl);

    policyCtrl.$inject = ['$rootScope','$uibModal','$location', 'policyService','url_constants','cacheService','localStorageService'];



    function policyCtrl($rootScope,$uibModal, $location, policyService, url_constants,cacheService,localStorageService){
        var currentUser = localStorageService.get("user");

      var vm = this;
      vm.documentData = {};
      vm.DocumentDTO={};
vm.newDocument={};
        vm.ui = { alert: false };
  vm.ui.validDateFormate = { alert : false };
    vm.ui.fileSize={alert:false};
    vm.ui.policyName={alert:false};
         vm.index = 0;
      vm.doc={};
      vm.showLoader = false;
vm.downloadPDF=url_constants.referencedownload;
vm.docUpload=url_constants.documentupload;

vm.role=currentUser.role;

vm.delete=url_constants.deleteDoc;
      var init = function () {
      vm.showLoader = true;
      console.log(cacheService);
      var cache = cacheService.get('cacheData');
           if (cache) {
             vm.documentData = cache;
              console.log(cache);
             vm.showLoader = false
                      }
      else {
      policyService.loadData(url_constants.loadDocumentData, function(response) {
        if(response.status==200){
          console.log(response.data);
          vm.documentData = response.data;
          cacheService.put('cacheData', vm.documentData);
          vm.showLoader = false;
        }
        else if(response.status==500){
          alert("Server Error,try after some time");
          $location.path('/menu');
        }
       });
    };
  };
      
      init();

         vm.downloadlinkPdf=function(id,name) {
  
      vm.downloadlinkPDF = vm.downloadPDF+'?Id='+id+'&name='+name;
      return  vm.downloadlinkPDF;
 
    }
vm.deletedata= function(id){
  if(confirm("Are you sure you want to delete this document")){
policyService.deletedata(url_constants.deleteDoc+'?Id='+id)
 window.location.reload();
}
else
return false;

}
   vm.open = function(id, size, status) {
        vm.showLoader = true;
         
           $rootScope.modalInstance = $uibModal.open({
            animation: true,
            templateUrl: 'app/modules/policyDocuments/views/policyUpload.html',
            controller: 'policyCtrl as vm',
            size: size
          
          });
        
         vm.showLoader = false;
      
    };
 vm.validFileFormat = function(){
            var fileName = vm.newDocument.file.filename;
            var fileSize = vm.newDocument.file.filesize;
            var fileBaseFormat = vm.newDocument.file.base64;
            var res = fileBaseFormat.substring(0, 5);
            var fileType = vm.newDocument.file.filetype;


          console.log( vm.newDocument.file);
          if(fileType === "application/pdf"){
            document.getElementById("rmb_claim_btn_add1").disabled=false
            vm.ui.fileSize.alert=false;
             vm.ui.validDateFormate.alert = false;console.log(vm.ui.validDateFormate.alert)
          }
          else{
            vm.ui.fileSize.alert=false;
            vm.ui.validDateFormate.alert = true;
            document.getElementById("rmb_claim_btn_add1").disabled=true;
            console.log(vm.ui.validDateFormate.alert)
            
          }
        if(typeof vm.newDocument.text == 'undefined' || vm.newDocument.text==null || vm.newDocument.text==""){
              document.getElementById("rmb_claim_btn_add1").disabled=true;
            }
      }

 vm.addToClaim = function() {

if(typeof vm.newDocument.text == 'undefined'|| vm.newDocument.text==null || vm.newDocument.text==""){
          
              vm.ui.policyName.alert=true;
    }
    else{
   vm.DocumentDTO.fileName = vm.newDocument.file.filename;
   vm.DocumentDTO.file  = vm.newDocument.file.base64;
    

   vm.DocumentDTO.documentName =rmb_claim_txt_doc1.value;
   policyService.uploadData(vm.DocumentDTO,url_constants.documentupload,function(response) {
        if(response.status==200){
          console.log(response.data);
          vm.showLoader = false;
           window.location.reload();
        }
        else if(response.status==500){
          alert("Server Error,try after some time");
          $location.path('/menu');
        }
       });
  };
}

  vm.cancel = function() {
   $rootScope.modalInstance.close('cancel');
  };

    }


})();