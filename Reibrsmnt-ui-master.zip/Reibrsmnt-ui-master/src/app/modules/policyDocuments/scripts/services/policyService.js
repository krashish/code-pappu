(function(){
	'use strict';
	angular.module('policy')
	       .service('policyService', policyService);

	policyService.$inject = ['$http'];
	
	function policyService($http){

		var service = {
      loadData:loadData,
      uploadData:uploadData,
      deletedata:deletedata
    };

	function loadData(Url, callback) {
      var req = {
        method: 'GET',
        url: Url,
        headers: {
          'Content-Type': 'application/json'
        },
      };
      $http(req)
        .then(function (response) {
          callback(response);
            return response;
          }, 
              function (response) {
                callback (response);
                  return response;
              }
          )
    };

function uploadData(claim, claimUrl, callback) {
    var req = {
      method: 'POST',
      url: claimUrl,
      headers: {
       'Content-Type': 'application/json'
      },
      data: claim
    };
    $http(req)
      .then(function(response) {
        callback(response);
        }, function(response){
          callback(response);
        }
      );
  };

  function deletedata(claimUrl, callback) {
    var req = {
      method: 'GET',
      url: claimUrl,
      headers: {
       'Content-Type': 'application/json'
      }
    };
    $http(req)
      .then(function(response) {
        callback(response);
        }, function(response){
          callback(response);
        }
      );
  };


    return service;
	}
       
})();