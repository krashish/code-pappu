/* @ngInject */
angular.module('policy' ,[]);