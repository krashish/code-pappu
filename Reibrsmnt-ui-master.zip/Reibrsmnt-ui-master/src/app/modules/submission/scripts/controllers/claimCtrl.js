(function() {
 'use strict';
 angular
  .module('submission')
  .controller('ClaimsCtrl', ClaimsCtrl);

 ClaimsCtrl.$inject = ['$rootScope', 'claimService', 'documentService', 'localStorageService','$location','url_constants'];

 function ClaimsCtrl($rootScope, claimService, documentService, localStorageService, $location, url_constants) {
  var vm = this;

  vm.showLoader = false;
  vm.initData = {};
  vm.documentId = 1;
  vm.newDocument = {};
  vm.index = 0;
  vm.claim = {};
  vm.claim.claimRequestHeaderVo = {};
  vm.claim.claimRequestHeaderVo.claimedAmount = 0;
  vm.claim["claimRequestDetailList"] = [];
  vm.periodFromPopup = false;
  vm.periodToPopup = false;
  vm.ui = { alert: false };
  vm.ui.validDateFormate = { alert : false };
  vm.ui.getProjectCodeNA = { alert : false };
  vm.ui.getProjectCodeExists = { alert : false };
  vm.ui.fileSize={alert:false};
  vm.validDaysCount = 0;
  vm.claim.claimRequestHeaderVo.specialApprove = false;
  vm.currentRole= localStorageService.get('user').role;
  vm.userId= localStorageService.get('user').employeeId;

  vm.init = function() {
    vm.showLoader = true;
    claimService.loadData(vm.userId, url_constants.claimLoadUrl, function(response) {

    vm.initData = response;
    console.log(vm.initData);
    vm.showLoader = false;
    });
  };
  
  vm.init();

  vm.datepickerPopupOpen = function (inputName){
    switch(inputName) {
      case 'periodFrom':
          vm.periodFromPopup = true;
          break;
      case 'periodTo':
          vm.periodToPopup = true;
          break;
      case 'billDate':
          vm.billDatePopup = true;
          break;
          case 'billFromDatePopup':
          vm.billFromDatePopup = true;
          break;
          case 'billToDatePopup':
          vm.billToDatePopup = true;
          break;
      default:
          alert("Error : Please contact finance department");
    }
  }

   vm.validDate = function() {
    var claimDate = moment(vm.initData.claimDate).format('DD/MM/YYYY');
    var periodTo = moment(vm.claim.claimRequestHeaderVo.periodTo).format('DD/MM/YYYY');
    var _claimDate = moment(claimDate, 'DD/MM/YYYY');
    var _periodTo = moment(periodTo, 'DD/MM/YYYY');
    vm.validDaysCount = _claimDate.diff(_periodTo, 'days');
     if((vm.validDaysCount)>60){
          vm.ui.alert = true;
          vm.claim.claimRequestHeaderVo.specialApprove = true;
      }
      else{
         vm.ui.alert = false;
         vm.claim.claimRequestHeaderVo.specialApprove = false;
      };
    }
      
           vm.validFileFormat = function(){
            var fileName = vm.newDocument.file.filename;
            var fileSize = vm.newDocument.file.filesize;
            var fileBaseFormat = vm.newDocument.file.base64;
            var res = fileBaseFormat.substring(0, 5);
            var fileType = vm.newDocument.file.filetype;
          console.log( vm.newDocument.file);
          if(fileSize>=1000000){
            vm.ui.fileSize.alert=true;
          }else{
            vm.ui.fileSize.alert=false;
            if(res==="/9j/4" && fileType === "image/jpeg"){
              vm.ui.fileSize.alert=false;
             vm.ui.validDateFormate.alert = false;console.log(vm.ui.validDateFormate.alert)
          }
          else if(res==="iVBOR" && fileType === "image/png"){
            vm.ui.fileSize.alert=false;
             vm.ui.validDateFormate.alert = false;console.log(vm.ui.validDateFormate.alert)
          }
          else if(res==="R0lGO" && fileType === "image/gif"){
            vm.ui.fileSize.alert=false;
             vm.ui.validDateFormate.alert = false;console.log(vm.ui.validDateFormate.alert)
          }
          else if(res==="JVBER" && fileType === "application/pdf"){
            vm.ui.fileSize.alert=false;
             vm.ui.validDateFormate.alert = false;console.log(vm.ui.validDateFormate.alert)
          }
          else if(res==="0M8R4" && fileType === "application/vnd.ms-excel"){
            vm.ui.fileSize.alert=false;
             vm.ui.validDateFormate.alert = false;console.log(vm.ui.validDateFormate.alert+res+fileType)
          }
          else if(res==="UEsDB" && fileType === "application/vnd.openxmlformats-officedocument.wordprocessingml.document"){
             vm.ui.fileSize.alert=false;
             vm.ui.validDateFormate.alert = false;console.log(vm.ui.validDateFormate.alert)
          }
          else{
            vm.ui.fileSize.alert=false;
            vm.ui.validDateFormate.alert = true;
            console.log(vm.ui.validDateFormate.alert)
            
          }
        }
      }

   vm.getProjectCode = function(){
    if(vm.reportTo==="RM"){
        vm.ui.getProjectCodeNA.alert = false;
        vm.ui.getProjectCodeExists.alert = true;
    }else{
      if(vm.claim.claimRequestHeaderVo.projectId.id === 1){
        vm.ui.getProjectCodeNA.alert = false;
        vm.ui.getProjectCodeExists.alert = true;
      }
      else{
        vm.ui.getProjectCodeExists.alert = false;
        vm.ui.getProjectCodeNA.alert = true;
      }

    }
      
  };
  

  vm.removeBill = function() {
   vm.newDocument = {};
   vm.claim.claimRequestDetailList = [];
   vm.index = 0;
   vm.documentId = 1;
   vm.claim.claimRequestHeaderVo.claimedAmount = 0;
   if(vm.claim.claimRequestHeaderVo.claimType==4 && vm.claim.claimRequestHeaderVo.clientBillable == null){
    
    vm.claim.claimRequestHeaderVo.clientBillable=false;
    console.log(vm.claim.claimRequestHeaderVo.clientBillable);
    
   }
  };
  vm.addToClaim = function() {

   vm.newDocument.id = vm.documentId++;
   vm.claim.claimRequestDetailList[vm.index] = vm.newDocument;

   vm.claim.claimRequestDetailList[vm.index].fileName = vm.newDocument.file.filename;
   vm.claim.claimRequestDetailList[vm.index].file = vm.newDocument.file.base64;
   //vm.claim.claimRequestDetailList[vm.index].billDate = moment(vm.claim.claimRequestDetailList[vm.index].billDate).format('DD/MM/YYYY');
   vm.index = vm.index + 1;
   vm.claim.claimRequestHeaderVo.claimedAmount = documentService.totalAmount(vm.claim.claimRequestHeaderVo.claimedAmount, vm.newDocument.claimAmount, "add");
   vm.newDocument = {};
  };
  vm.delete = function(id) {
   var claimDetailArray = eval(vm.claim.claimRequestDetailList);
   var rowIndex = documentService.rowIndex(claimDetailArray, id);
   if (rowIndex === -1) {
    alert("Something went wrong");
   } else {
    vm.claim.claimRequestHeaderVo.claimedAmount = documentService.totalAmount(vm.claim.claimRequestHeaderVo.claimedAmount, vm.claim.claimRequestDetailList[rowIndex].claimAmount, "delete");
    vm.claim.claimRequestDetailList.splice(rowIndex, 1);
    vm.index--;
   }
  };

  vm.acceptDeclaration = function(){
    console.log(vm.acceptDeclarationValue);
  };

  vm.submitClaim = function(submitType) {
    vm.showLoader = true;
    var curentUser = localStorageService.get('user');
    vm.claim.claimRequestHeaderVo.claimCurrency = parseInt(vm.claim.claimRequestHeaderVo.claimCurrency, 10);
    vm.claim.claimRequestHeaderVo.claimType = parseInt(vm.claim.claimRequestHeaderVo.claimType, 10);
    vm.claim.claimRequestHeaderVo.managerId = curentUser.managerId;
    vm.claim.claimRequestHeaderVo.employeeId = curentUser.employeeId;
    //vm.claim.claimRequestHeaderVo.periodFrom = moment(vm.claim.claimRequestHeaderVo.periodFrom).format('DD/MM/YYYY');
    //vm.claim.claimRequestHeaderVo.periodTo = moment(vm.claim.claimRequestHeaderVo.periodTo).format('DD/MM/YYYY');
    vm.claim.claimRequestHeaderVo.projectId = vm.claim.claimRequestHeaderVo.projectId.id;
     vm.claim.claimRequestHeaderVo.specialApprove = vm.claim.claimRequestHeaderVo.specialApprove;
    vm.claim.claimRequestHeaderVo.submitType = submitType;
    console.log(vm.claim);
          claimService.submit(vm.claim, url_constants.claimSubmitUrl, function(response) {
            if(response.status==200){
             window.location.reload();
              $location.path('/menu');
              vm.showLoader = false;
            }
            else if(response.status==500){
              alert("Please enter valid data to proceed");
              console.log(response.statusText);
              vm.showLoader = false;
            }
         });
      }
 

  };

})();