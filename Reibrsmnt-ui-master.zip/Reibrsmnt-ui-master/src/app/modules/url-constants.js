// constants.js

(function() {
  'use strict';
  angular
  .module('reibrsmnt.config.url',[])
  .constant('url_constants', (function() {
    var baseUrl = 'http://192.168.63.40:8080/ReibrsmntSvc';
    var authUrl = 'http://192.168.63.40:8006';
    return {
    adminFormUrl: baseUrl + '/adminform/',
    authDetailsUrl: baseUrl + '/userdetail',
    claimApproveUrl: baseUrl + '/approve/claims/',
    loginUrl: authUrl + '/oauth/token',
    claimLoadUrl: baseUrl + '/claims?userId=',
    claimSubmitUrl: baseUrl + '/claims',
    userClaimUrl: baseUrl + '/users/claims/',
    claimRequestUrl: baseUrl + '/claims/details?',
    projectDetailsUrl:baseUrl + '/review',
    projectWiseDetailsUrl:baseUrl + '/review/details?',
    updateAdminUrl: baseUrl + '/updateAdmin/',
    empSearchUrl: baseUrl + '/usersList/?user=',
    userConfigDetailUrl:baseUrl + '/config/getEmployee?userId=',
    claimDeleteUrl: baseUrl + '/claims/',
    statusReportDownloadUrl: baseUrl + '/claims/analysis/report',
    faqDetailsUrl: baseUrl + '/faq',
    loadDocumentData: baseUrl + '/reference/documents/load',
    referencedownload: baseUrl + '/reference/documents/downloadPDF',
    documentupload: baseUrl+ '/reference/documents/upload',
    deleteDoc:baseUrl+'/reference/documents/delete'
    }
  })())
})();