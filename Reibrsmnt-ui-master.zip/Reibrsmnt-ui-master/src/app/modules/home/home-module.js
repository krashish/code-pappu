/* @ngInject */
angular.module('home' ,['ngAnimate']);