(function(){
	'use strict';
	angular
		.module('home')
		.service('profileService', profileService);

		profileService.$inject=[];

	function profileService() {
		var service = {};
		service.loadData = function (loginUrl, callback) {

		}
	};

})();