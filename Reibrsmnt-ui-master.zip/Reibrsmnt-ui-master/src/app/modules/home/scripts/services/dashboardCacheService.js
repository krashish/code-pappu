/*(function(){
	'use strict';
	angular.module('faq')
	       .factory('dashboardCacheService', dashboardCacheService);

    dashboardCacheService.$inject = ['$cacheFactory'];

   function dashboardCacheService($cacheFactory) {
    	       	return $cacheFactory('casheDataClaims','casheDataclaimsToApprove');
    	       };	
 })();  	              */