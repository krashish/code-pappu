(function(){
	'use strict';
	angular.module('Reibrsmnt')
	       .service('projectWiseClaimDetailsService', projectWiseClaimDetailsService);

	projectWiseClaimDetailsService.$inject = ['$http'];
	
	function projectWiseClaimDetailsService($http){

		var service = {
      loadData:loadData,
      projectWiseClaimDetails:projectWiseClaimDetails
    };

	function loadData(Url, callback) {
      var req = {
        method: 'GET',
        url: Url,
        headers: {
          'Content-Type': 'application/json'
        },
      };
      $http(req)
        .then(
          function (response) {
            callback(response);
              return response;
          }, 
          function (response) {
            callback (response);
              return response;
              }
          )
    };
      function projectWiseClaimDetails(id, statusCode, periodFrom, periodTo, Url, callback) {
      var req = {
        method: 'GET',
        url: Url+ 'projectId=' + id + '&status=' + statusCode + '&fromDate=' + periodFrom + '&toDate=' + periodTo,
        headers: {
          'Content-Type': 'application/json'
        },
      };
      $http(req)
        .then(function (response) {
          callback(response);
            return response;
          }, 
              function (response) {
                callback (response);
                  return response;
              }
          )
    };
    return service;
	}
       
})();