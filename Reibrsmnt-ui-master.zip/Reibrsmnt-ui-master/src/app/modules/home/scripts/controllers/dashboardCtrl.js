(function() {

   'use strict'
   angular.module('Reibrsmnt')
    .controller('DashboardCtrl', DashboardCtrl);

   DashboardCtrl.$inject = ['$uibModal', 'dashBoardService','cacheService', '$rootScope', '$location','localStorageService', 'url_constants'];

   function DashboardCtrl($uibModal, dashBoardService,cacheService, $rootScope, location,localStorageService,url_constants) {

    var vm = this;
    vm.claims = [];
    vm.claimsToApprove = [];
    vm.showLoader = true;
    vm.reportFormPopup = false;
    vm.reportToPopup = false;
    vm.currentUser=localStorageService.get("user");
    var currentUser = localStorageService.get("user");
    var role = currentUser.role;
    
    
    vm.init = function() {
      vm.showLoader = true;
       var casheDataClaims = cacheService.get('casheDataClaims');
       var casheDataclaimsToApprove = cacheService.get('casheDataclaimsToApprove');
           if (casheDataClaims && casheDataclaimsToApprove) {
             vm.claims = casheDataClaims;
             vm.claimsToApprove = casheDataclaimsToApprove;
             //console.log(casheDataClaims);
             //console.log(casheDataclaimsToApprove);
             vm.showLoader = false
                      }
      else {
      dashBoardService.getClaims(currentUser.employeeId, url_constants.userClaimUrl,
        function receivedClaims(response) {
          vm.claims = response.claimRequestList;
          vm.claimsToApprove = response.claimApproveList;
          //console.log( vm.claims);
         // console.log( vm.claimsToApprove);
          cacheService.put('casheDataClaims', vm.claims);
          cacheService.put('casheDataclaimsToApprove', vm.claimsToApprove);
          vm.showLoader = false;
      });
    };
  };

    vm.init(); 

    vm.datepickerPopupOpen = function (inputName){
    switch(inputName) {
      case 'reportFrom':
          vm.reportFormPopup = true;
          break;
      case 'reportTo':
          vm.reportToPopup = true;
          break;
      default:
          alert("Error : Please contect finance Team");
    }
  }

    vm.isEmpty = function() {
      if (vm.claims == "")
        return true;
      else
        return false;
    }

    vm.normUser = function() {
      if (role == "NormalUser")
        return true;
      else
        return false;
    }

    vm.editStatus = function(status) {
     if (status == "Draft" || status=="Review")
      return false;
     else
      return true;
    }



    vm.deleteClaim = function(claimId) {
      var index = -1;
      dashBoardService.deleteClaims(claimId, url_constants.claimDeleteUrl, function(response) {
        if (response.status == 200) {
          var claimArray = eval(vm.claims);
          for (var i = 0; i < claimArray.length; i++) {
            if (claimArray[i].id === claimId) {
              index = i;
              vm.claims.splice(index, 1);
              break;
            };
          };
          if (index == -1) {
          alert("Something gone wrong !!!");
          };
        }
        else {
          alert(response.error);
        };
      });
    };

    vm.claimDetails = function(id) {
     location.path("/menu/claimApprove/" + id);
     vm.showLoader = false;
    };
    /* vm.showRequestClaimDeails = function(id) {
     location.path("/menu/claimApprove/" + id);
     vm.showLoader = false;
    };
    vm.projectWiseClaimDetails = function(id) {
     location.path("/menu/claimApprove/" + id);
     vm.showLoader = false;
    };
*/
   



    vm.open = function(id, size, status) {
      if (status == 'Draft' || status=='Review') {
       
        dashBoardService.getClaim(id,currentUser.employeeId, url_constants.claimRequestUrl, function(response, status) {
          vm.claim = response;
          console.log(vm.claim);
          var modalInstance = $uibModal.open({
            animation: true,
            templateUrl: 'app/modules/submission/views/edit.html',
            controller: 'editCtrl as vm',
            size: size,
            resolve: {
              claimId: function() {
                return id;
              },
              claimDetails: function() {
                return response;
              }
            }
          });
        });
        // vm.showLoader = false;
      };
    };
   };
})();
