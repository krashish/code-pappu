(function(){
   'use strict'
   angular.module('Reibrsmnt')
    .controller('projectWiseClaimDetailsCtrl', projectWiseClaimDetailsCtrl);

   projectWiseClaimDetailsCtrl.$inject = ['$uibModal', 'projectWiseClaimDetailsService', '$rootScope', '$location','localStorageService', 'url_constants'];

   function projectWiseClaimDetailsCtrl($uibModal, projectWiseClaimDetailsService, $rootScope, location,localStorageService,url_constants) {
   var vm = this;
   vm.projectWiseDetails=[];
   vm.buttonId=1;
   vm.totalAmount = 0 ;
   vm.showLoader = false;
   vm.reportFormPopup = false;
   vm.reportToPopup = false;
   vm.ui = { alert: false };
   vm.status = [{id:'2',type:'Pending'},
                {id:'3',type:'Approved'},
                {id:'5',type:'Forwarded'},
                {id:'7',type:'Cleared'}
               ];
   console.log(vm.status);
   vm.statusReportDownloadUrl = url_constants.statusReportDownloadUrl;
   vm.init = function() {
      vm.showLoader = true;
      projectWiseClaimDetailsService.loadData(url_constants.projectDetailsUrl, function (response) {
          vm.initData = response.data;
          console.log(vm.initData);
          vm.showLoader = false;
      });
    }

    vm.init(); 

    vm.datepickerPopupOpen = function (inputName){
    switch(inputName) {
      case 'reportFrom':
          vm.reportFormPopup = true;
          break;
      case 'reportTo':
          vm.reportToPopup = true;
          break;
      default:
          alert("Error : Please contact finance Team");
    }
  };
   vm.isEmpty = function() {
      if (vm.claims == "")
        return true;
      else
        return false;
    }
    
   vm.reportFromChange = function() {
      vm.fromDate = moment(vm.reportFrom).format('DD/MM/YYYY');
      //vm.downloadlink = vm.statusReportDownloadUrl + '?projectId='+ vm.projectDetails.id +'&fromDate='+vm.fromDate+'&toDate='+vm.toDate;
    };

    vm.reportToChange = function() {
      vm.toDate = moment(vm.reportTo).format('DD/MM/YYYY');
    
    };
    vm.button1=function () {
      vm.showLoader = true;
      vm.buttonId=1;
      vm.projectWiseDetails=[];
      vm.projectDetails="";
      vm.showLoader = false;
    }
    vm.button2=function () {
      vm.showLoader = true;
      vm.projectWiseDetails=[];
      vm.buttonId=2;
      vm.projectId=0;
      vm.showLoader = false;
    }
    vm.button3=function () {
      vm.showLoader = true;
      vm.projectWiseDetails=[];
      vm.buttonId=3;
      vm.projectId=1;
      vm.showLoader = false;
    }
    vm.downloadlinkPdf=function () {
      vm.format='pdf';

         console.log(vm.fromDate + "hi..." + vm.projectId + "hello..." + vm.toDate);
         if(vm.buttonId==1){
          vm.projectId=vm.projectDetails.id;
      }
      
      if(undefined==vm.reportFrom){
                if(undefined==vm.reportTo){
                  vm.fromDate=vm.toDate=null;
                 }else{
                  vm.fromDate=null;
                 }
        }
      else if(undefined==vm.reportTo){
                if(undefined==vm.reportFrom){
                  vm.fromDate=vm.toDate=null;
                }else{
                  vm.toDate=null;
                }  
      } 
      console.log(vm.fromDate + "hi..." + vm.projectId + "hello..." + vm.toDate);
      vm.downloadlinkPDF = vm.statusReportDownloadUrl + '?projectId='+ vm.projectId 
                    +'&fromDate='+vm.fromDate+'&toDate='+vm.toDate +'&format='+vm.format;
 
    }
    vm.downloadlinkXLS=function () {
      vm.formatcsv='csv';
         console.log(vm.fromDate + vm.projectId + vm.toDate);
         if(vm.buttonId==1){
          vm.projectId=vm.projectDetails.id;
      }
      
      if(undefined==vm.reportFrom){
                if(undefined==vm.reportTo){
                  vm.fromDate=vm.toDate=null;
                 }else{
                  vm.fromDate=null;
                 }
        }
      else if(undefined==vm.reportTo){
                if(undefined==vm.reportFrom){
                  vm.fromDate=vm.toDate=null;
                }else{
                  vm.toDate=null;
                }  
      } 
      console.log(vm.fromDate + vm.projectId + vm.toDate);
      vm.downloadlinkCsv = vm.statusReportDownloadUrl + '?projectId='+ vm.projectId 
                    +'&fromDate='+vm.fromDate+'&toDate='+vm.toDate +'&format='+vm.formatcsv;
 
    }
/*   vm.myFunction =function (divName) {
     alert("hello");
     var printContents = document.getElementById(divName).innerHTML;
     var originalContents = document.body.innerHTML;

     document.body.innerHTML = printContents;

     window.print();

     document.body.innerHTML = originalContents;
}*/
vm.myFunction =  function (divName) {
var disp_setting="toolbar=yes,location=no,";
disp_setting+="directories=yes,menubar=yes,";
disp_setting+="scrollbars=yes,width=1320, height=770, left=50, top=25";
   var content_vlue = document.getElementById(divName).innerHTML;
   var docprint=window.open('','_blank',disp_setting);
   docprint.document.open();
   docprint.document.write('<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"');
   docprint.document.write('"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">');
   docprint.document.write('<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">');
   docprint.document.write('<head><title>My Title</title>');
  
   docprint.document.write('<style type="text/css">body{ margin:0px;');
   docprint.document.write('font-family:verdana,Arial;color:#000;');
   docprint.document.write('font-family:Verdana, Geneva, sans-serif; font-size:12px;}');
   docprint.document.write('a{color:#000;text-decoration:none;} </style>');

   docprint.document.write('<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />');
   docprint.document.write('<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.min.css" />');

   docprint.document.write('<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/angular-ui-grid/3.2.9/ui-grid.css" />');
   docprint.document.write('<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.11.2/css/bootstrap-select.css" />');
   docprint.document.write('<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/angular-ui-bootstrap/2.1.4/ui-bootstrap.min.js" ></script>');
   docprint.document.write('</head><body onLoad="self.print()"><center>');
   docprint.document.write(content_vlue);
   docprint.document.write('</center></body></html>');
   docprint.document.close();
   docprint.focus();
}
  
    vm.projectWiseClaimDetails= function() {
      if(vm.buttonId==1){
          vm.projectId=vm.projectDetails.id;
      }
      if(undefined == vm.statusType){
          vm.statusCode = 0;
      }else{
        vm.statusCode= vm.statusType;
      }
      
      if(undefined==vm.reportFrom){
                if(undefined==vm.reportTo){
                  vm.fromDate=vm.toDate=null;
                 }else{
                  vm.fromDate=null;
                 }
        }
      else if(undefined==vm.reportTo){
                if(undefined==vm.reportFrom){
                  vm.fromDate=vm.toDate=null;
                }else{
                  vm.toDate=null;
                }  
      } 
        
        
        projectWiseClaimDetailsService.projectWiseClaimDetails(vm.projectId, vm.statusCode, vm.fromDate, vm.toDate,  url_constants.projectWiseDetailsUrl, function(response) {
          vm.projectWiseDetails = response.data;
          var projectDetails = vm.projectWiseDetails;
          var totalAmt =0;
          for(var i=0; i< projectDetails.length; i++){

            if(projectDetails[i].currencyCode=="INR"){
              totalAmt = projectDetails[i].claimedAmount + totalAmt;
            }else if(projectDetails[i].currencyCode=="USD"){
             totalAmt = ((projectDetails[i].claimedAmount) * 65) + totalAmt;
            }else if(projectDetails[i].currencyCode=="CAD"){
              totalAmt = ((projectDetails[i].claimedAmount) * 50.74)+ totalAmt;
            }else{
              totalAmt = ((projectDetails[i].claimedAmount) * 3.45) + totalAmt;
            }
           
          } 
          vm.totalAmount = totalAmt;
          console.log(response.data);
          if(response.data.length===0){
             vm.ui.alert=true;
           
          }
           
          else{
            vm.ui.alert=false; 
            
          }
            
        });
    };

    vm.claimDetails = function(id) {
     location.path("/menu/claimApprove/" + id);
     vm.showLoader = false;
    };


   }


})();