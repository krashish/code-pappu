/* @ngInject */
angular.module('admin', ['LocalStorageModule']);
