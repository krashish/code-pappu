  (function() {
 'use strict';

 angular
  .module('approval')
  .controller('ClaimApproveCtrl', ClaimApproveCtrl);

 ClaimApproveCtrl.$inject = ['approvalService', '$stateParams','localStorageService', 'approve_type', '$location', '$rootScope', 'url_constants'];

 function ClaimApproveCtrl(approvalService, stateParams, localStorageService, approve_type,location, $rootScope, url_constants) {
  var vm = this;
  vm.showLoader= true;
  vm.alerts = [ ];
  var currentUser = localStorageService.get('user');
  
  vm.currentEmployeeName = currentUser.employeeName;
  console.log(currentUser.employeeName);
  var claimId = parseInt(stateParams.claimId);

  vm.init = function() {
   approvalService.loadClaim(claimId,  currentUser.employeeId, url_constants.claimRequestUrl, function(response) {
    vm.initData = response.data;
    console.log(vm.initData);
    vm.claimHeader = vm.initData.claimRequestHeaderVo;
    vm.cliamDocuments = vm.initData.claimRequestDetailList;
    vm.approveDetailList = vm.initData.approveDetailsList;
    vm.showLoader= false;
   });
  };

  vm.init();
  
  vm.closeAlert = function(index) {
        vm.alerts.splice(index, 1);
      };

/*  vm.myFunction =function (divName) {

     var printContents = document.getElementById(divName).innerHTML;
     var originalContents = document.body.innerHTML;

     document.body.innerHTML = printContents;

     window.print();

     document.body.innerHTML = originalContents;
}*/
vm.myFunction =  function (divName) {
var disp_setting="toolbar=yes,location=no,";
disp_setting+="directories=yes,menubar=yes,";
disp_setting+="scrollbars=yes,width=1320, height=770, left=50, top=25";
   var content_vlue = document.getElementById(divName).innerHTML;
   var docprint=window.open('','_blank',disp_setting);
   docprint.document.open();
   docprint.document.write('<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"');
   docprint.document.write('"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">');
   docprint.document.write('<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">');
   docprint.document.write('<head><title>My Title</title>');
   docprint.document.write('<style type="text/css">body{ margin:10px;');
   docprint.document.write('font-family:verdana,Arial;color:#000;');
   docprint.document.write('font-family:Verdana, Geneva, sans-serif; font-size:12px;}');
   docprint.document.write('a{color:#000;text-decoration:none;} </style>');

   docprint.document.write('<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />');
   docprint.document.write('<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.min.css" />');

   docprint.document.write('<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/angular-ui-grid/3.2.9/ui-grid.css" />');
   docprint.document.write('<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.11.2/css/bootstrap-select.css" />');
   docprint.document.write('<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/angular-ui-bootstrap/2.1.4/ui-bootstrap.min.js" ></script>');
   docprint.document.write('</head><body onLoad="self.print()"><center>');
   docprint.document.write(content_vlue);
   docprint.document.write('</center></body></html>');
   docprint.document.close();
   docprint.focus();
}
  vm.submit = function(input) {
    vm.showLoader= true;
    vm.claimdata.employeeId = currentUser.employeeId;
    if (input == "approve") {
      vm.claimdata.claimsStatus = approve_type.approve;
    } 
    else if (input == "review") {
      vm.claimdata.claimsStatus = approve_type.review;
    } 
    else if (input == "reject") {
      vm.claimdata.claimsStatus = approve_type.reject;
    } 
    else if (input == "forward") {
      vm.claimdata.claimsStatus = approve_type.forward;
    }
    else if (input == "hold") {
      vm.claimdata.claimsStatus = approve_type.hold;
    }
    else if (input == "cleared") {
      vm.claimdata.claimsStatus = approve_type.cleared;
    }
    approvalService.submitclaim(vm.claimdata, url_constants.claimApproveUrl, claimId,
     function(response) {
      if(response.status==200){
        console.log(url_constants.claimApproveUrl)
        vm.alerts.push({type: 'success', msg: response.statusText});
        location.path("/dashboard");  
        vm.showLoader= false;
      }
      else if(response.status==500){
        // alert(response.statusText);
        vm.alerts.push({type: 'danger', msg: response.statusText});
        vm.showLoader= false;
      }
      else {
        vm.alerts.push({type: 'danger', msg: response.statusText});
        vm.showLoader= false;
      }
    });
  };

 };
})();