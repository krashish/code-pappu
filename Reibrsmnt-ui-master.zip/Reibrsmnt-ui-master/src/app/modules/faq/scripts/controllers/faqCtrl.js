(function(){
  'use strict';
  angular.module('faq')
         .controller('faqCtrl', faqCtrl);

    faqCtrl.$inject = ['$rootScope','$location', 'faqService','url_constants','cacheService'];

    function faqCtrl($rootScope, $location, faqService, url_constants,cacheService){
      var vm = this;
      vm.faqData = {};
      vm.showLoader = false;

      var init = function () {
      vm.showLoader = true;
      console.log(cacheService);
      var cache = cacheService.get('cachefaqData');
           if (cache) {
             vm.faqData = cache;
              console.log(cache);
             vm.showLoader = false
                      }
      else {
      faqService.loadData(url_constants.faqDetailsUrl, function(response) {
        if(response.status==200){
          console.log(response.data);
          vm.faqData = response.data;
          cacheService.put('cachefaqData', vm.faqData);
          vm.showLoader = false;
        }
        else if(response.status==500){
          alert("Server Error,try after some time");
          $location.path('/menu');
        }
       });
    };
  };
      
      init();
    }

})();