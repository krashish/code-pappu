/*(function(){
	'use strict';
	angular.module('faq')
	       .factory('faqCacheService', faqCacheService);

    faqCacheService.$inject = ['$cacheFactory'];

    function faqCacheService($cacheFactory) {
    	       	return $cacheFactory('cacheData');
    	       };	
 })();   	              */