(function(){
	'use strict';
	angular.module('faq')
	       .service('faqService', faqService);

	faqService.$inject = ['$http'];
	
	function faqService($http){

		var service = {
      loadData:loadData
    };

	function loadData(Url, callback) {
      var req = {
        method: 'GET',
        url: Url,
        headers: {
          'Content-Type': 'application/json'
        },
      };
      $http(req)
        .then(function (response) {
          callback(response);
            return response;
          }, 
              function (response) {
                callback (response);
                  return response;
              }
          )
    };
    return service;
	}
       
})();