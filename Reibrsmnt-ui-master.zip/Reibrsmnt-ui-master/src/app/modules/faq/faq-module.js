/* @ngInject */
angular.module('faq' ,[]);